#
# If you want to use this conffile, remove all comments and put files that
# you want dpkg to process here using their absolute pathnames.
# See section 9.1 of the packaging manual.
#
# for example:
# /etc/pnet/pnet.conf
