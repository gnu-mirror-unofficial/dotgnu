#include <ffi.h>

#define CHECK(x) !(x) ? abort() : 0 

