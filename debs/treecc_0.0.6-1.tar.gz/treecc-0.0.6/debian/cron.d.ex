#
# Regular cron jobs for the treecc package
#
0 4	* * *	root	treecc_maintenance
