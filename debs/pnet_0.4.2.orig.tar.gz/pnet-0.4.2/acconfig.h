#undef HAVE_LIBREADLINE
#undef HAVE_LIBHISTORY
#undef FREEBSD_THREADS
#undef GC_HPUX_THREADS
#undef GC_IRIX_THREADS
#undef GC_LINUX_THREADS
#undef GC_SOLARIS_PTHREADS
#undef GC_SOLARIS_THREADS
#undef _REENTRANT
#undef DGUX_THREADS
#undef GC_DGUX386_THREADS
#undef GC_FREEBSD_THREADS
#undef GC_WIN32_THREADS
#undef PARALLEL_MARK
#undef THREAD_LOCAL_ALLOC
#undef _POSIX_C_SOURCE

/* Define if you have support for computed gotos */
#undef HAVE_COMPUTED_GOTO

/* Define if you have support for computed gotos in read-only PIC code */
#undef HAVE_PIC_COMPUTED_GOTO

/* Define if you have libffi */
#undef HAVE_LIBFFI

/* Define if you have libgc */
#undef HAVE_LIBGC
