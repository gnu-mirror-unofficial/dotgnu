/* include/il_config.h.  Generated automatically by configure.  */
/* include/il_config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if using alloca.c.  */
/* #undef C_ALLOCA */

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define to one of _getb67, GETB67, getb67 for Cray-2 and Cray-YMP systems.
   This function is required for alloca.c support on those systems.  */
/* #undef CRAY_STACKSEG_END */

/* Define if you have alloca, as a function or macro.  */
#define HAVE_ALLOCA 1

/* Define if you have <alloca.h> and it should be used (not on Ultrix).  */
#define HAVE_ALLOCA_H 1

/* Define if you have <sys/wait.h> that is POSIX.1 compatible.  */
#define HAVE_SYS_WAIT_H 1

/* If using the C implementation of alloca, define if you know the
   direction of stack growth for your system; otherwise it will be
   automatically deduced at run-time.
 STACK_DIRECTION > 0 => grows toward higher addresses
 STACK_DIRECTION < 0 => grows toward lower addresses
 STACK_DIRECTION = 0 => direction of growth unknown
 */
/* #undef STACK_DIRECTION */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 1

/* Define if lex declares yytext as a char * by default, not a char[].  */
#define YYTEXT_POINTER 1

#define HAVE_LIBREADLINE 1
#define HAVE_LIBHISTORY 1
/* #undef FREEBSD_THREADS */
/* #undef GC_HPUX_THREADS */
/* #undef GC_IRIX_THREADS */
#define GC_LINUX_THREADS 1
/* #undef GC_SOLARIS_PTHREADS */
/* #undef GC_SOLARIS_THREADS */
#define _REENTRANT 1
/* #undef DGUX_THREADS */
/* #undef GC_DGUX386_THREADS */
/* #undef GC_FREEBSD_THREADS */
/* #undef GC_WIN32_THREADS */
/* #undef PARALLEL_MARK */
#define THREAD_LOCAL_ALLOC 1
/* #undef _POSIX_C_SOURCE */

/* The number of bytes in a double.  */
#define SIZEOF_DOUBLE 8

/* The number of bytes in a float.  */
#define SIZEOF_FLOAT 4

/* The number of bytes in a int.  */
#define SIZEOF_INT 4

/* The number of bytes in a long.  */
#define SIZEOF_LONG 4

/* The number of bytes in a long double.  */
#define SIZEOF_LONG_DOUBLE 12

/* The number of bytes in a long long.  */
#define SIZEOF_LONG_LONG 8

/* The number of bytes in a void *.  */
#define SIZEOF_VOID_P 4

/* Define if you have the acos function.  */
#define HAVE_ACOS 1

/* Define if you have the asin function.  */
#define HAVE_ASIN 1

/* Define if you have the atan function.  */
#define HAVE_ATAN 1

/* Define if you have the atan2 function.  */
#define HAVE_ATAN2 1

/* Define if you have the bcmp function.  */
#define HAVE_BCMP 1

/* Define if you have the bcopy function.  */
#define HAVE_BCOPY 1

/* Define if you have the bzero function.  */
#define HAVE_BZERO 1

/* Define if you have the ceil function.  */
#define HAVE_CEIL 1

/* Define if you have the cos function.  */
#define HAVE_COS 1

/* Define if you have the cosh function.  */
#define HAVE_COSH 1

/* Define if you have the dlopen function.  */
#define HAVE_DLOPEN 1

/* Define if you have the execv function.  */
#define HAVE_EXECV 1

/* Define if you have the exp function.  */
#define HAVE_EXP 1

/* Define if you have the fcntl function.  */
#define HAVE_FCNTL 1

/* Define if you have the finite function.  */
#define HAVE_FINITE 1

/* Define if you have the floor function.  */
#define HAVE_FLOOR 1

/* Define if you have the fmod function.  */
#define HAVE_FMOD 1

/* Define if you have the fork function.  */
#define HAVE_FORK 1

/* Define if you have the ftruncate function.  */
#define HAVE_FTRUNCATE 1

/* Define if you have the get_current_dir_name function.  */
#define HAVE_GET_CURRENT_DIR_NAME 1

/* Define if you have the getcwd function.  */
#define HAVE_GETCWD 1

/* Define if you have the getpagesize function.  */
#define HAVE_GETPAGESIZE 1

/* Define if you have the getpid function.  */
#define HAVE_GETPID 1

/* Define if you have the gettimeofday function.  */
#define HAVE_GETTIMEOFDAY 1

/* Define if you have the getwd function.  */
#define HAVE_GETWD 1

/* Define if you have the isinf function.  */
#define HAVE_ISINF 1

/* Define if you have the isnan function.  */
#define HAVE_ISNAN 1

/* Define if you have the log function.  */
#define HAVE_LOG 1

/* Define if you have the log10 function.  */
#define HAVE_LOG10 1

/* Define if you have the mbrtowc function.  */
#define HAVE_MBRTOWC 1

/* Define if you have the mbtowc function.  */
#define HAVE_MBTOWC 1

/* Define if you have the memchr function.  */
#define HAVE_MEMCHR 1

/* Define if you have the memcmp function.  */
#define HAVE_MEMCMP 1

/* Define if you have the memcpy function.  */
#define HAVE_MEMCPY 1

/* Define if you have the memmove function.  */
#define HAVE_MEMMOVE 1

/* Define if you have the memset function.  */
#define HAVE_MEMSET 1

/* Define if you have the mmap function.  */
#define HAVE_MMAP 1

/* Define if you have the munmap function.  */
#define HAVE_MUNMAP 1

/* Define if you have the nl_langinfo function.  */
#define HAVE_NL_LANGINFO 1

/* Define if you have the open function.  */
#define HAVE_OPEN 1

/* Define if you have the pow function.  */
#define HAVE_POW 1

/* Define if you have the qsort function.  */
#define HAVE_QSORT 1

/* Define if you have the re_comp function.  */
#define HAVE_RE_COMP 1

/* Define if you have the regcomp function.  */
#define HAVE_REGCOMP 1

/* Define if you have the remainder function.  */
#define HAVE_REMAINDER 1

/* Define if you have the remove function.  */
#define HAVE_REMOVE 1

/* Define if you have the rint function.  */
#define HAVE_RINT 1

/* Define if you have the setlocale function.  */
#define HAVE_SETLOCALE 1

/* Define if you have the sin function.  */
#define HAVE_SIN 1

/* Define if you have the sinh function.  */
#define HAVE_SINH 1

/* Define if you have the sqrt function.  */
#define HAVE_SQRT 1

/* Define if you have the stat function.  */
#define HAVE_STAT 1

/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if you have the strtod function.  */
#define HAVE_STRTOD 1

/* Define if you have the tan function.  */
#define HAVE_TAN 1

/* Define if you have the tanh function.  */
#define HAVE_TANH 1

/* Define if you have the unlink function.  */
#define HAVE_UNLINK 1

/* Define if you have the usleep function.  */
#define HAVE_USLEEP 1

/* Define if you have the vfprintf function.  */
#define HAVE_VFPRINTF 1

/* Define if you have the wait function.  */
#define HAVE_WAIT 1

/* Define if you have the waitpid function.  */
#define HAVE_WAITPID 1

/* Define if you have the wcrtomb function.  */
#define HAVE_WCRTOMB 1

/* Define if you have the wctomb function.  */
#define HAVE_WCTOMB 1

/* Define if you have the <dlfcn.h> header file.  */
#define HAVE_DLFCN_H 1

/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H 1

/* Define if you have the <ieeefp.h> header file.  */
/* #undef HAVE_IEEEFP_H */

/* Define if you have the <langinfo.h> header file.  */
#define HAVE_LANGINFO_H 1

/* Define if you have the <locale.h> header file.  */
#define HAVE_LOCALE_H 1

/* Define if you have the <math.h> header file.  */
#define HAVE_MATH_H 1

/* Define if you have the <memory.h> header file.  */
#define HAVE_MEMORY_H 1

/* Define if you have the <netinet/in.h> header file.  */
#define HAVE_NETINET_IN_H 1

/* Define if you have the <readline/history.h> header file.  */
#define HAVE_READLINE_HISTORY_H 1

/* Define if you have the <readline/readline.h> header file.  */
#define HAVE_READLINE_READLINE_H 1

/* Define if you have the <regex.h> header file.  */
#define HAVE_REGEX_H 1

/* Define if you have the <stdarg.h> header file.  */
#define HAVE_STDARG_H 1

/* Define if you have the <stdlib.h> header file.  */
#define HAVE_STDLIB_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <strings.h> header file.  */
#define HAVE_STRINGS_H 1

/* Define if you have the <sys/mman.h> header file.  */
#define HAVE_SYS_MMAN_H 1

/* Define if you have the <sys/select.h> header file.  */
#define HAVE_SYS_SELECT_H 1

/* Define if you have the <sys/socket.h> header file.  */
#define HAVE_SYS_SOCKET_H 1

/* Define if you have the <sys/stat.h> header file.  */
#define HAVE_SYS_STAT_H 1

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <sys/types.h> header file.  */
#define HAVE_SYS_TYPES_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the <varargs.h> header file.  */
#define HAVE_VARARGS_H 1

/* Define if you have the <wchar.h> header file.  */
#define HAVE_WCHAR_H 1

/* Define if you have the dl library (-ldl).  */
#define HAVE_LIBDL 1

/* Define if you have the m library (-lm).  */
#define HAVE_LIBM 1

/* Name of package */
#define PACKAGE "pnet"

/* Version number of package */
#define VERSION "0.3.6"

