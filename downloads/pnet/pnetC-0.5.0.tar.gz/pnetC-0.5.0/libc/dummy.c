/* Exists just to fool automake into outputting
   C compilation logic into the "Makefile" */
