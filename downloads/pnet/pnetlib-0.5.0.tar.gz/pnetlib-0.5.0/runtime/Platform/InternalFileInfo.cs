namespace Platform
{

using System;

internal struct InternalFileInfo
{
	public String fileName;
	public FileType fileType;
}

} // namespace Platform
