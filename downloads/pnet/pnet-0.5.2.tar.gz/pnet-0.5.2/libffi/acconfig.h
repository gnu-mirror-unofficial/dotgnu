/* Define this if you want extra debugging */
#undef FFI_DEBUG

/* Define this if you are using Purify and want to suppress 
   spurious messages. */
#undef USING_PURIFY

/* Define this is you do not want support for aggregate types.  */
#undef FFI_NO_STRUCTS

/* Define this is you do not want support for the raw API.  */
#undef FFI_NO_RAW_API
